/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pkg41425018_pascalfelipesawaki_sesi03;

/**
 *
 * @author Pascal Felipe Sawaki
 */

/*
Nim : Pascal Felipe Sawaki
NIM : 41425018
*/

import java.util.Scanner;

public class LoginSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Data akun valid (untuk simulasi)
        final String USERNAME_BENAR = "admin";
        final String PASSWORD_BENAR = "password123";

        int percobaan = 1;
        final int MAKS_PERCOBAAN = 3;
        boolean loginBerhasil = false;

        System.out.println("=== Sistem Login ===");

        while (percobaan <= MAKS_PERCOBAAN && !loginBerhasil) {
            System.out.println("Percobaan " + percobaan + ":");
            System.out.print("Username: ");
            String username = scanner.nextLine();
            System.out.print("Password: ");
            String password = scanner.nextLine();

            // 1. Validasi panjang username (5 - 10 karakter)
            if (username.length() < 5 || username.length() > 10) {
                System.out.println("Login gagal! Username harus antara 5-10 karakter.");
            }
            // 2. Validasi password (minimal 8 karakter dan mengandung angka)
            else if (password.length() < 8 || !password.matches(".*\\d.*")) {
                System.out.println("Login gagal! Password harus minimal 8 karakter dan mengandung angka.");
            }
            // 3. Pengecekan kredensial login
            else if (username.equals(USERNAME_BENAR) && password.equals(PASSWORD_BENAR)) {
                System.out.println("Login berhasil!");
                loginBerhasil = true;
            } else {
                System.out.println("Login gagal! Password salah.");
            }

            // Jika belum berhasil dan masih ada sisa percobaan
            if (!loginBerhasil) {
                percobaan++;
                if (percobaan > MAKS_PERCOBAAN) {
                    System.out.println("Akun terkunci! Terlalu banyak percobaan gagal.");
                }
            }
        }

        scanner.close();
    }
}