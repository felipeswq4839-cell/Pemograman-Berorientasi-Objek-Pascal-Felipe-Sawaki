/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pbo_w02s02_41425018;

/**
 *
 * @author Pascal Felipe Sawaki
 */

/*
Nim: 41425018
Nama:Pascal Felipe Sawaki
*/

import java.util.Scanner;

public class LoginSederhana {
    public static void main(String [] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Masukan nama lengkap: ");
        String nama = input.nextLine();
        
        System.out.println("Panjang string: " + nama.length());
        System.out.println("Huruf Pertama: " + nama.charAt(0));
        System.out.println("Pengandung Spasi: " + nama.contains(" "));
    }
}

/*
1. Tetap memberikan kendali untuuk input selama tombol enter tidak di pencet
*/