/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pbo_w02s02_41425018;

/**
 *
 * @author Pascal Felipe Sawaki
 */

/*
Nim: 41425018
Nama:Pascal Felipe Sawaki
*/

import java.util.Scanner;

public class Kalkulator {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Masukkan angka pertama: ");
        int a = input.nextInt();
        System.out.print("Masukkan angka kedua: ");
        int b = input.nextInt();

        System.out.println("Tambah: " + (a + b));
        System.out.println("Kurang: " + (a - b));
        System.out.println("Kali: " + (a * b));
        System.out.println("Bagi: " + ((double) a / b));
    }
}

/*
1. Double memiliki koma/titik desimal, sedangkan int membuat yang punya koma tidak lagi (64.3 -> 64)
2.Agar hasilnya berupa desimal (3.7), bukan pembagian bulat (7).
3. Akan muncul error/infinity
*/