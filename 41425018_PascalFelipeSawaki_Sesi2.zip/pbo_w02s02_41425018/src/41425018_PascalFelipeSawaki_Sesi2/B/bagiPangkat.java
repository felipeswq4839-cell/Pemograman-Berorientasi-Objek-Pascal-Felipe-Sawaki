/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pbo_w02s02_41425018.B;

/**
 *
 * @author Pascal Felipe Sawaki
 */

/*
Nim: 41425018
Nama:Pascal Felipe Sawaki
*/

import java.util.Scanner;

public class bagiPangkat {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Masukkan angka pertama: ");
        int a = input.nextInt();
        System.out.print("Masukkan angka kedua: ");
        int b = input.nextInt();
        int sisaBagi = a % b;
        int pangkat = (int) Math.pow(a, b);
        System.out.println("Sisa bagi: " + sisaBagi);
        System.out.println("Pangkat: " + pangkat);
    }
}